#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  8 16:26:45 2023

@author: frindel
"""
from Brique import Brique
from brique_speciale import BriqueSpeciale

class CasseBriques:
    """
    Classe représentant le jeu de casse-briques.
    """

    def __init__(self):
        """
        Initialise une instance de CasseBriques avec une liste vide de briques et un score initialisé à zéro.
        """
        self.briques = []
        self.score = 0

    def ajouter_brique(self, brique):
        """
        Ajoute une brique à la liste des briques du jeu.

        Args:
            brique (Brique): La brique à ajouter.
        """
        self.briques += [brique]

    def afficher_briques(self):
        """
        Affiche les caractéristiques de chaque brique dans la liste des briques.
        """
        for brique in self.briques:
            print(brique)

    def impact_brique(self, ball_x, ball_y):
        """
        Retourne la brique touchée (objet) ou None.
        """
        for brique in self.briques:
            pts = brique.is_hit(ball_x, ball_y)
            if pts > 0:
                self.score += pts
                if brique.solidite == 0:
                    self.briques.remove(brique)
                    print(f'brique {brique} détruite')
                return brique
        return None

    def afficher_score(self):
        """
        Affiche le score actuel du jeu.
        """
        print(f'le score est de {self.score} points')

    def construire_rangee_briques(self, couleur, solidite, points, nombre_briques, espace_entre_briques=5, numero_ligne=1):
        """
        Construit une rangée de briques avec les caractéristiques spécifiées et les ajoute au jeu.

        Args:
            couleur (str): La couleur des briques.
            solidite (int): La solidité des briques.
            points (int): Le nombre de points attribués lorsque la balle détruit la brique.
            nombre_briques (int): Le nombre de briques dans la rangée.
            espace_entre_briques (int, optional): L'espace horizontal entre les briques. Par défaut, 5.
            numero_ligne (int, optional): Le numéro de la ligne où placer les briques. Par défaut, 1.
        """
        # Ajoute une rangée de briques horizontalement
        largeur_brique = 50  # Remplacez par la largeur souhaitée
        hauteur_brique = 25  # Remplacez par la hauteur souhaitée
        position_y = espace_entre_briques + (hauteur_brique + espace_entre_briques) * (numero_ligne-1)  # Ajuste la position en y de la rangée
        position_x = espace_entre_briques

        for _ in range(nombre_briques):
            brique = Brique(couleur, solidite, points, position_x, position_y, largeur_brique, hauteur_brique)
            self.ajouter_brique(brique)
            position_x += largeur_brique + espace_entre_briques
