# -*- coding: utf-8 -*-
"""
Created on Wed Mar  4 14:29:00 2026

@author: alpho
"""
from Brique import Brique

class BriqueSpeciale(Brique):
    
    def __init__(self, couleur, solidite, points, x_position, y_position, largeur, hauteur, effet_special):
        super().__init__(couleur, solidite, points, x_position, y_position, largeur, hauteur)
        self.effet_special = effet_special
    
    def is_hit(self, ball_x, ball_y):
        pts_gagnes = super().is_hit(ball_x, ball_y)
        if pts_gagnes > 0 and self.effet_special == 'Double Score':
                pts_gagnes *= 2
        return pts_gagnes 
    
    def __str__(self):
        return super().__str__() + f'Elle a {self.effet_special} comme pouvoir.'
