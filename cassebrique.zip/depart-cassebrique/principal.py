# -*- coding: utf-8 -*-
"""
Created on Wed Mar  4 15:35:17 2026

@author: alpho
"""

from Brique import Brique
from brique_speciale import BriqueSpeciale
from CasseBriquesGUI import CasseBriquesGUI
from CasseBriques import CasseBriques

cassebriques = CasseBriques()

cassebriques.construire_rangee_briques('red', 3, 10, 14, numero_ligne= 1)
cassebriques.construire_rangee_briques('blue', 2, 15, 14, numero_ligne= 2)
cassebriques.construire_rangee_briques('green', 1, 15, 14, numero_ligne= 3)

fenetre = CasseBriquesGUI(cassebriques)

fenetre.demarrer()