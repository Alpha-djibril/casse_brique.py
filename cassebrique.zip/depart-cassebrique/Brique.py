# -*- coding: utf-8 -*-
"""
Created on Wed Feb 25 14:47:23 2026

@author: alpho
"""

class Brique:
    def __init__(self, couleur, solidite, points, x_position, y_position, largeur, hauteur):
        self.couleur = couleur
        self.solidite = solidite
        self.points = points
        self.y_position = y_position
        self.x_position = x_position
        self.largeur = largeur
        self.hauteur = hauteur
    
    def __str__(self):
        return f'brique {self.couleur}, de solidité {self.solidite} à la position {self.x_position, self.y_position}. Elle a pour dimensions {self.largeur, self.hauteur} et donne {self.points} points'
    
    def get_limits(self):
        return (self.x_position, self.y_position, self.x_position + self.largeur, self.y_position + self.hauteur)
    
    def is_hit(self, ball_x, ball_y):
        limits = self.get_limits()
        pts_gagnes = 0
        if (limits[0] <= ball_x <= limits[2]) and (limits[1] <= ball_y <= limits[3]) :
            self.solidite -= 1
            pts_gagnes += self.points
            print(f'brique {(self.x_position, self.y_position)} touchée. Solidité restante {self.solidite}')
        return pts_gagnes
        
